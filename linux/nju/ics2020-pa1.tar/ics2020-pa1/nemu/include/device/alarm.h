#ifndef __DEVICE_ALARM_H__
#define __DEVICE_ALARM_H__

void add_alarm_handle(void *h);

#endif
