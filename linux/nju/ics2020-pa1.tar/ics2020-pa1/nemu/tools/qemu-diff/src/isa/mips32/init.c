void init_isa() {
}
