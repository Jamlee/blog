#ifndef __DIFFTEST_H__
#define __DIFFTEST_H__

#define DIFFTEST_REG_SIZE (sizeof(uint32_t) * 33) // GRPs + pc

#endif
