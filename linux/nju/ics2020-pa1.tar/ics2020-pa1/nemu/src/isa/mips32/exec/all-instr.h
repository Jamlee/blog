#include "../local-include/rtl.h"

#include "compute.h"
#include "control.h"
#include "ldst.h"
#include "muldiv.h"
#include "system.h"

def_EHelper(inv);
def_EHelper(nemu_trap);
