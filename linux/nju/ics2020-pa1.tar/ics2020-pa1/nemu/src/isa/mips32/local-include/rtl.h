#ifndef __MIPS32_RTL_H__
#define __MIPS32_RTL_H__

#include <rtl/rtl.h>
#include "reg.h"

// no isa-dependent rtl instructions

#endif
