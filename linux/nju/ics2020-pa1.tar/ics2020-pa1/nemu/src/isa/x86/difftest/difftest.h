#ifndef __DIFFTEST_H__
#define __DIFFTEST_H__

#define DIFFTEST_REG_SIZE (sizeof(uint32_t) * 9) // GRPs + PC

#endif
