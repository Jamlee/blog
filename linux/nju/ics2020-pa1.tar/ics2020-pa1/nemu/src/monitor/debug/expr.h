#ifndef __EXPR_H__
#define __EXPR_H__

#include <common.h>

word_t expr(char *, bool *);

#endif
